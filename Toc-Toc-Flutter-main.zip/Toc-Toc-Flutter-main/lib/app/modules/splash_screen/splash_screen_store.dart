import 'package:flutter_triple/flutter_triple.dart';

class SplashScreenStore extends Store<int> {

  SplashScreenStore() : super(0);

}