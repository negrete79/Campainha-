import 'dart:ui';

class MyColors {
  static const textColor = Color(0xFF635C5C);
  static const blue = Color(0xFF0B6EFE);
  static const lightGray = Color(0xFFECE9EC);
  static const errorRed = Color(0xFFCB0000);
}